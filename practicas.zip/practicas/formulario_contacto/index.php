<?php
if(isset($_POST['submit']){
	$nombre = $_POST['nombre'];
	$correo = $_POST['correo'];
	$mensaje = $_POST['mensaje'];
	
	if
	
}

require 'index.view.php';


?>