<!DOCTYPE html>
<html lang = "en">
<head>
	<meta charset = "UTF-8">
	<title>Formulario Contacto</title>
	<link href = 'https://fonts.googleapis.com/css?family=Roboto' rel = 'stylesheet' type = 'text/css'>
	<link rel = "sytlesheet" href= "estilos.css">
</head>
<body>
	<div class = "wrap">
		<form action = "<?php print_r(htmlspecialchars($_SERVER['PHP_SELF']) ?>" method = "POST">
			<input type = "text" class = "form-control" id = "id_nombre" name = "nombre" placeholder = "Nombre" value = "">
			
			<input type = "text" class = "form-control" id = "id_correo" name = "correo" placeholder = "Correo" value = "">
			
			<textarea name = "mensaje" class = "form-control id = "id_mensaje" placeholder = "Mensaje"></textarea>
			
			<div class = "alert error">
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde, temporibus?
			</div>
			
			<div class = "alert success">
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde, temporibus?
			</div>
			
			<input type = "submit" name = "submit" class = "btn btn-primary" value = "Enviar correo">
		</form>
	</div>
</body>
</html>