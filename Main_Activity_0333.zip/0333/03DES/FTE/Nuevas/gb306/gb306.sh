fglpc gb306.4gl
fglpc gb000.4gl
fglpc ad800.4gl
fglpc in000.4gl
form4gl gb306a.per
cat gb306.4go gb000.4go ad800.4go in000.4go  > gb306.4gi
fglgo gb306 MGG 
