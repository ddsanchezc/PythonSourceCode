fglpc gbp001.4gl
fglpc gb000.4gl
form4gl gbp001a.per
cat  gbp001.4go gb000.4go > gbp001.4gi
fglgo gbp001.4gi EAY