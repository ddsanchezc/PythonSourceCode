fglpc gb306ef.4gl
fglpc gb000.4gl
form4gl gb306efa.per
cat gb306ef.4go gb000.4go > gb306ef.4gi
