form4gl gb306dva
fglpc gb306dv
cat gb306dv.4go gb000.4go > gb306dv.4gi
